# VideoForge AI Free — GitHub দিয়ে APK বানানোর নিয়ম

এই project-এ Backend URL নেই। GitHub Actions ব্যবহার করে ফোন/ব্রাউজার থেকেই APK build করা যাবে।

## ১) GitHub-এ নতুন Repository বানান
GitHub খুলে **New repository** চাপুন।
নাম দিতে পারেন:

`VideoForgeAI-Free`

Public repository হলে সবচেয়ে সহজে Actions চালানো যায়।

## ২) ZIP খুলে সব ফাইল Upload করুন
এই ZIP-এর ভেতরের **সব ফাইল ও folder** repository-এর root-এ upload করুন।

বিশেষ করে এই ফাইলটি থাকতে হবে:

`.github/workflows/build-apk.yml`

## ৩) Actions চালান
Repository → **Actions** → **Build VideoForge AI Free APK** → **Run workflow**

অথবা `main`/`master` branch-এ push করলেও workflow নিজে চালু হবে।

## ৪) APK নিন
Build শেষ হলে:

**Actions → সফল workflow → Artifacts → VideoForgeAI-Free-debug**

ZIP artifact download করে তার ভেতরের `.apk` ফোনে install করুন।

## গুরুত্বপূর্ণ
- এটি **debug APK**; Play Store release-এর জন্য আলাদা signing দরকার।
- এই Free version offline-first: template script, Android Text-to-Speech এবং local scene cards ব্যবহার করে।
- সত্যিকারের online generative AI image/video/script চাইলে আলাদা AI provider/backend লাগবে।
- Android Studio লাগবে না; GitHub Actions cloud runner-এ build করবে।
