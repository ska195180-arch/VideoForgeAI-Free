
# VideoForge AI Free — Backend URL ছাড়া APK Project

এটি একটি **Android-only Free/Offline-first** ভার্সন।

## কী আছে
- Backend URL নেই
- ইন্টারনেট/API key ছাড়াই script template তৈরি
- Android-এর TextToSpeech দিয়ে voice file বানানোর চেষ্টা
- Pillow/FFmpeg নয়; Android Bitmap/Canvas দিয়ে scene cards
- Jetpack Media3 Transformer দিয়ে scene images + voice থেকে MP4 export
- SRT subtitle file তৈরি
- MP4 ও SRT share করার ব্যবস্থা
- বাংলা/ইংরেজি script
- Documentary / Story / Explainer / News template
- 1–10 মিনিট duration selector

## গুরুত্বপূর্ণ
এটি **real generative AI backend নয়**। Offline mode-এ script template ও device TTS ব্যবহার করা হয়। Android-এর TTS engine-এ বাংলা voice installed না থাকলে বাংলা voice synthesis কাজ নাও করতে পারে। Android TextToSpeech can synthesize text to a file; the app checks the result through an utterance progress listener.

Real AI research, AI image generation, premium neural voice, YouTube OAuth upload ইত্যাদি এই offline APK-তে নেই। সেগুলোর জন্য ভবিষ্যতে Online AI Mode যোগ করা যাবে।

## Build
1. Android Studio খুলুন।
2. এই ZIP extract করে `VideoForgeAI-Free` folder Open করুন।
3. Gradle sync হতে দিন।
4. JDK 17 এবং Android SDK 35 installed রাখুন।
5. `app` > `assembleDebug` চালান।
6. APK হবে `app/build/outputs/apk/debug/`-এ।

## Media3
এই project Jetpack Media3 Transformer 1.11.0 ব্যবহার করে। Android-এর official docs অনুযায়ী Transformer image inputs-কে নির্দিষ্ট duration-এর video clips হিসেবে নিতে পারে এবং MP4 export করতে পারে।

## No Backend URL
অ্যাপের startup screen-এ Backend URL field নেই এবং কোনো backend connection test নেই।
