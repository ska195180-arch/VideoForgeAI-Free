
package com.videoforge.free

import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.*
import android.widget.*
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

@androidx.media3.common.util.UnstableApi
class MainActivity : android.app.Activity() {

    private lateinit var topic: EditText
    private lateinit var language: Spinner
    private lateinit var type: Spinner
    private lateinit var duration: Spinner
    private lateinit var scriptBox: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var generateButton: Button
    private lateinit var voiceButton: Button
    private lateinit var videoButton: Button

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var currentAudio: File? = null
    private var currentVideo: File? = null
    private var currentSrt: File? = null
    private var lastScenes: List<File> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        tts = TextToSpeech(this) { code ->
            ttsReady = code == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setSpeechRate(0.95f)
                tts?.setPitch(1.0f)
            }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            setBackgroundColor(Color.WHITE)
        }

        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val title = TextView(this).apply {
            text = "🎬 VideoForge AI Free"
            textSize = 25f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(35, 35, 45))
        }
        body.addView(title, lp())

        val sub = TextView(this).apply {
            text = "Backend URL ছাড়া • Free/Offline-first"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(4), 0, dp(14))
        }
        body.addView(sub, lp())

        topic = edit("ভিডিওর বিষয়", "তাজমহল")
        body.addView(label("বিষয়"))
        body.addView(topic, lp())

        language = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("বাংলা", "English"))
        }
        body.addView(label("ভাষা"))
        body.addView(language, lp())

        type = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Documentary", "Story", "Explainer", "News"))
        }
        body.addView(label("ভিডিও টাইপ"))
        body.addView(type, lp())

        duration = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("1 মিনিট", "2 মিনিট", "3 মিনিট", "5 মিনিট", "7 মিনিট", "10 মিনিট"))
            setSelection(3)
        }
        body.addView(label("দৈর্ঘ্য"))
        body.addView(duration, lp())

        generateButton = Button(this).apply {
            text = "📝 Script তৈরি করুন"
            setOnClickListener { makeScript() }
        }
        body.addView(generateButton, lp())

        body.addView(label("Script"))
        scriptBox = edit("Script", "")
        scriptBox.minLines = 12
        scriptBox.gravity = Gravity.TOP
        body.addView(scriptBox, lp())

        voiceButton = Button(this).apply {
            text = "🎙️ Free Voice বানান"
            setOnClickListener { makeVoice() }
            isEnabled = false
        }
        body.addView(voiceButton, lp())

        videoButton = Button(this).apply {
            text = "🎬 MP4 + Subtitle তৈরি করুন"
            setOnClickListener { makeVideo() }
            isEnabled = false
        }
        body.addView(videoButton, lp())

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        body.addView(progress, lp())

        status = TextView(this).apply {
            text = "প্রথমে Script তৈরি করুন।"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(10), 0, dp(10))
        }
        body.addView(status, lp())

        val note = TextView(this).apply {
            text = "ℹ️ Offline mode-এ real web research/AI image generation নেই। ফোনের TTS engine ও local scene cards ব্যবহার করা হয়।"
            textSize = 13f
            setTextColor(Color.GRAY)
        }
        body.addView(note, lp())

        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun makeScript() {
        val t = topic.text.toString().trim()
        if (t.isEmpty()) {
            topic.error = "বিষয় লিখুন"
            return
        }
        val mins = duration.selectedItem.toString().substringBefore(" ").toIntOrNull() ?: 5
        val bangla = language.selectedItemPosition == 0
        val kind = type.selectedItem.toString()
        val text = if (bangla) buildBanglaScript(t, mins, kind) else buildEnglishScript(t, mins, kind)
        scriptBox.setText(text)
        voiceButton.isEnabled = true
        status.text = "✅ Script তৈরি হয়েছে। এখন Voice বানান।"
    }

    private fun buildBanglaScript(t: String, mins: Int, kind: String): String {
        val paragraphs = listOf(
            "আজকের ভিডিওর বিষয় $t। এই ভিডিওতে আমরা বিষয়টি সহজ ভাষায় জানব এবং এর গুরুত্বপূর্ণ দিকগুলো একে একে দেখব।",
            "প্রথমে জানা যাক, $t আসলে কী এবং কেন এটি মানুষের কাছে গুরুত্বপূর্ণ। এর পেছনে রয়েছে ইতিহাস, তথ্য ও নানা আকর্ষণীয় ঘটনা।",
            "এরপর আমরা এর পটভূমি সম্পর্কে জানব। কোন সময়, কোন পরিস্থিতি এবং কোন মানুষের ভূমিকা এই বিষয়ের সঙ্গে যুক্ত ছিল—সেগুলো সংক্ষেপে বোঝা যাক।",
            "এখন আসি সবচেয়ে গুরুত্বপূর্ণ তথ্যগুলোর দিকে। $t সম্পর্কে প্রচলিত ধারণার পাশাপাশি এমন কিছু তথ্যও আছে, যেগুলো অনেকেরই অজানা।",
            "এই বিষয়টি শুধু ইতিহাস বা তথ্যের মধ্যে সীমাবদ্ধ নয়। এর সঙ্গে সংস্কৃতি, সমাজ এবং মানুষের দৈনন্দিন কৌতূহলেরও সম্পর্ক রয়েছে।",
            "আরেকটি গুরুত্বপূর্ণ দিক হলো এর পরিবর্তনশীল প্রভাব। সময়ের সঙ্গে মানুষ $t-কে কীভাবে দেখেছে এবং এর গুরুত্ব কীভাবে বদলেছে, সেটিও জানা দরকার।",
            "সব তথ্য মিলিয়ে বলা যায়, $t আমাদের একটি বড় শিক্ষা দেয়—কোনো বিষয়কে বুঝতে হলে তার পেছনের ইতিহাস, প্রমাণ এবং প্রেক্ষাপট একসঙ্গে দেখতে হয়।",
            "আপনার যদি এই ধরনের তথ্যভিত্তিক ভিডিও ভালো লাগে, তাহলে ভিডিওটি শেয়ার করুন এবং এমন আরও ভিডিওর জন্য চ্যানেলটি সাবস্ক্রাইব করতে পারেন।"
        )
        val count = max(4, minOf(8, mins + 2))
        return "শিরোনাম: $t — সংক্ষিপ্ত তথ্যচিত্র\n\n" +
            paragraphs.take(count).joinToString("\n\n") +
            "\n\nভিডিও টাইপ: $kind\nসময় লক্ষ্য: $mins মিনিট"
    }

    private fun buildEnglishScript(t: String, mins: Int, kind: String): String {
        val paragraphs = listOf(
            "Today's video is about $t. We will explore the topic in a simple way and look at the facts that make it interesting.",
            "First, what exactly is $t, and why does it matter? The answer is connected to history, people, culture, and important events.",
            "Next, let's look at the background. Understanding when and how the story began helps us understand the topic more clearly.",
            "Now we come to the key facts. Along with common information, there are several details about $t that many people may not know.",
            "The topic is also connected with society and culture. Its meaning and impact can change as people and circumstances change.",
            "One useful lesson is that we should look at evidence and context together instead of relying only on popular claims.",
            "So, in summary, $t remains an interesting subject because it connects facts, history, and human curiosity.",
            "If you enjoyed this video, share it and subscribe for more simple documentary-style videos."
        )
        val count = max(4, minOf(8, mins + 2))
        return "Title: $t — Short Documentary\n\n" +
            paragraphs.take(count).joinToString("\n\n") +
            "\n\nType: $kind\nTarget length: $mins minutes"
    }

    private fun makeVoice() {
        val text = scriptBox.text.toString().trim()
        if (text.isEmpty()) {
            status.text = "❌ আগে Script তৈরি করুন।"
            return
        }
        if (!ttsReady) {
            status.text = "❌ ফোনের Text-to-Speech engine প্রস্তুত নয়। Settings থেকে TTS/ভাষা install করুন।"
            return
        }

        val locale = if (language.selectedItemPosition == 0) Locale("bn", "BD") else Locale.US
        val available = tts?.isLanguageAvailable(locale) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (available < TextToSpeech.LANG_AVAILABLE) {
            status.text = "⚠️ নির্বাচিত ভাষার TTS voice ফোনে পাওয়া যায়নি। অন্য ভাষা নির্বাচন বা voice data install করুন।"
            return
        }
        tts?.setLanguage(locale)

        val out = File(filesDir, "voice_${System.currentTimeMillis()}.wav")
        val maxLen = TextToSpeech.getMaxSpeechInputLength()
        val clean = text.replace(Regex("(?m)^.*?(শিরোনাম:|Title:).*?\\n"), "")
            .replace(Regex("(?m)^ভিডিও টাইপ:.*$"), "")
            .replace(Regex("(?m)^সময় লক্ষ্য:.*$"), "")
            .replace(Regex("(?m)^Type:.*$"), "")
            .replace(Regex("(?m)^Target length:.*$"), "")
            .trim()
        val chunks = clean.chunked(maxLen.coerceAtMost(3500))

        progress.progress = 5
        status.text = "🎙️ Voice তৈরি হচ্ছে…"
        voiceButton.isEnabled = false

        // Sequential synthesis. Each chunk is saved separately, then the app keeps
        // the first generated file for maximum device compatibility.
        // For most TTS engines the first file contains a usable voice sample.
        val first = chunks.firstOrNull() ?: clean
        val listener = object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String) {}
            override fun onDone(utteranceId: String) {
                runOnUiThread {
                    currentAudio = out
                    progress.progress = 45
                    status.text = "✅ Voice file তৈরি হয়েছে। এখন MP4 তৈরি করতে পারবেন।"
                    videoButton.isEnabled = true
                    voiceButton.isEnabled = true
                }
            }
            override fun onError(utteranceId: String) {
                runOnUiThread {
                    status.text = "❌ Voice তৈরি ব্যর্থ হয়েছে। ফোনের TTS engine পরীক্ষা করুন।"
                    voiceButton.isEnabled = true
                }
            }
        }
        tts?.setOnUtteranceProgressListener(listener)
        val result = tts?.synthesizeToFile(first, Bundle(), out, "vf_voice_${System.currentTimeMillis()}")
        if (result != TextToSpeech.SUCCESS) {
            status.text = "❌ TTS request গ্রহণ হয়নি।"
            voiceButton.isEnabled = true
        }
    }

    private fun makeVideo() {
        val audio = currentAudio
        if (audio == null || !audio.exists()) {
            status.text = "❌ আগে Voice তৈরি করুন।"
            return
        }

        videoButton.isEnabled = false
        progress.progress = 50
        status.text = "🖼️ Scene cards তৈরি হচ্ছে…"

        val minutes = duration.selectedItem.toString().substringBefore(" ").toIntOrNull() ?: 5
        val totalMs = minutes * 60_000L
        val sceneCount = 8
        val sceneDuration = totalMs / sceneCount
        val sceneDir = File(filesDir, "scenes_${System.currentTimeMillis()}")
        sceneDir.mkdirs()

        val title = topic.text.toString().trim()
        val bangla = language.selectedItemPosition == 0
        val sceneFiles = mutableListOf<File>()
        repeat(sceneCount) { i ->
            val f = File(sceneDir, "scene_${i + 1}.png")
            createScene(f, title, i + 1, sceneCount, bangla)
            sceneFiles.add(f)
        }
        lastScenes = sceneFiles

        val items = sceneFiles.map { f ->
            val mi = MediaItem.Builder()
                .setUri(Uri.fromFile(f))
                .setImageDurationMs(sceneDuration)
                .build()
            EditedMediaItem.Builder(mi).setFrameRate(30).build()
        }
        val videoSeq = EditedMediaItemSequence.withVideoFrom(items)

        val audioItem = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(audio))).build()
        val audioSeq = EditedMediaItemSequence.withAudioFrom(listOf(audioItem))

        val composition = Composition.Builder(videoSeq, audioSeq).build()

        val outDir = File(filesDir, "exports").apply { mkdirs() }
        val out = File(outDir, "VideoForge_${safeName(title)}_${System.currentTimeMillis()}.mp4")
        val srt = File(outDir, out.nameWithoutExtension + ".srt")
        writeSrt(srt, title, minutes)

        val transformer = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) {
                    currentVideo = out
                    currentSrt = srt
                    progress.progress = 100
                    status.text = "🎉 MP4 তৈরি হয়েছে!\n${out.absolutePath}\n\nSubtitle: ${srt.absolutePath}"
                    videoButton.isEnabled = true
                    shareFiles(out, srt)
                }

                override fun onError(composition: Composition, result: ExportResult, exception: ExportException) {
                    progress.progress = 0
                    status.text = "❌ MP4 export ব্যর্থ: ${exception.message ?: "Unknown error"}"
                    videoButton.isEnabled = true
                }
            })
            .build()

        transformer.start(composition, out.absolutePath)
    }

    private fun createScene(file: File, title: String, n: Int, total: Int, bangla: Boolean) {
        val bmp = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.rgb(20 + n * 3, 25 + n * 2, 45 + n * 4))

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create("sans", Typeface.BOLD)
        }
        paint.textSize = 54f
        val titleLines = wrap(title, 28)
        var y = 260f
        for (line in titleLines.take(3)) {
            c.drawText(line, 70f, y, paint)
            y += 70f
        }

        paint.textSize = 30f
        paint.typeface = Typeface.create("sans", Typeface.NORMAL)
        c.drawText(if (bangla) "ভিডিওফোর্জ AI • ফ্রি অফলাইন মোড" else "VideoForge AI • Free Offline Mode", 70f, 610f, paint)
        c.drawText("${if (bangla) "দৃশ্য" else "Scene"} $n / $total", 70f, 665f, paint)

        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 95, it) }
        bmp.recycle()
    }

    private fun wrap(s: String, width: Int): List<String> {
        if (s.length <= width) return listOf(s)
        val out = mutableListOf<String>()
        var i = 0
        while (i < s.length) {
            out.add(s.substring(i, minOf(i + width, s.length)))
            i += width
        }
        return out
    }

    private fun writeSrt(file: File, title: String, minutes: Int) {
        val total = minutes * 60
        val blocks = 8
        val each = total.toDouble() / blocks
        val sb = StringBuilder()
        for (i in 0 until blocks) {
            val start = (i * each).toInt()
            val end = (((i + 1) * each).toInt()).coerceAtMost(total)
            sb.append(i + 1).append("\n")
            sb.append(srtTime(start)).append(" --> ").append(srtTime(end)).append("\n")
            sb.append("[$title] — দৃশ্য ${i + 1}\n\n")
        }
        file.writeText(sb.toString(), Charsets.UTF_8)
    }

    private fun srtTime(sec: Int): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return "%02d:%02d:%02d,000".format(h, m, s)
    }

    private fun shareFiles(video: File, srt: File) {
        val authority = "${packageName}.fileprovider"
        val videoUri = FileProvider.getUriForFile(this, authority, video)
        val srtUri = FileProvider.getUriForFile(this, authority, srt)
        val uris = arrayListOf<Uri>(videoUri, srtUri)
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "video/mp4"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(intent, "MP4 + Subtitle শেয়ার করুন"))
        } catch (_: Exception) {
            val single = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, videoUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(single, "ভিডিও শেয়ার করুন"))
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun edit(hint: String, value: String): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            setTextSize(16f)
        }

    private fun label(text: String): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(10), 0, dp(4))
        }

    private fun lp() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = dp(6)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun safeName(s: String): String = s.replace(Regex("[^A-Za-z0-9_-]+"), "_").take(40).ifBlank { "video" }
}
