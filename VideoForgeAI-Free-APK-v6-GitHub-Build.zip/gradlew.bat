@echo off
REM Gradle wrapper launcher placeholder. Use Android Studio's Gradle panel or installed Gradle.
gradle %*
